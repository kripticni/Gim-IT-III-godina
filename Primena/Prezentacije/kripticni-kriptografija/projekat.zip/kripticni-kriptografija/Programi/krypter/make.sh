#!/usr/bin/env bash

g++ src/krypter.cpp -Llib -lkryptos -o bin/krypter
