# Praktičan deo

## Za one koji nikad nisu radili CTF

**CTF** označava **Capture The Flag**, poenta CTF-a  
je da rešite zadatak i time dodjete do string-a  
koji se dobija kada se dodje do kraja zadatka  
to se naziva **Flag**, ili _zastava_.  
  
  
Rešenja CTF-a uvek zapisujete u formatu:  
`<ime ctf organizacije>ctf{zastava}`  
U CTF-ovima flag se može naći samo kao  
zastava, ili formatirano kao zapis iznad.  
  
  
Za CTF koji sam vam pripremio, format je  
`GimCTF{zastava}`

***

## Enkriptovani fajlovi

Gimnazija Bora Stanković je nedavno bila hakovana  
i ključan fajl o osnivanju Gimnazije je bio šifrovan  
a hakeri traže otkup za njega.  
Na svu sreću hakeri nisu stigli da obrišu neke ključeve 
s kojima su šifrovali ovaj fajl, pa su se profesori  
dogovorili da će prvo tražiti pomoć učenika IT smera III7.  
Da li možete da im pomognete?

Ako uspete da povratite fajl, od važnosti je da njegovu  
hash vrednost pošaljete ministarstvu na adresi 0.0.0.0:50007,  
Kako bi oni proverili integritet.
